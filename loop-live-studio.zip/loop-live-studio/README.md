# Loop Live Studio (Termux)

## Install on Android Termux

```sh
pkg update && pkg upgrade
pkg install nodejs ffmpeg unzip
cd ~/live-stream-site # or your chosen project folder
```

Extract/copy this project into a folder you own, then:

```sh
npm install
node server.js
```

Open `http://127.0.0.1:3000` in the same phone's browser. Keep Termux open and exempt it from Android battery optimization if you need long sessions.

## Stream modes
- Horizontal: 16:9 output, one YouTube stream key.
- Vertical: 9:16 output, one YouTube stream key.
- Both: two independent FFmpeg processes and two separate YouTube stream keys. It doubles encoding/upload workload. Use low bitrate/resolution first and verify the phone/network can sustain it.

## Important
- Upload video files in the dashboard or put supported files in `videos/` (MP4/MOV/MKV/WEBM/M4V).
- If FFmpeg cannot decode a source, convert it to H.264 video + AAC audio first.
- Keys are kept in server memory only and are not saved to disk. Do not share screenshots showing keys. If a key was exposed, reset it in YouTube Studio.
- The web server binds to `127.0.0.1` only. Do not expose it to the public internet without adding authentication and HTTPS.
- YouTube must have the matching live event configured for each output. This tool sends video to the provided RTMPS key; it does not create YouTube events.
- 24/7 uptime is not guaranteed on Android; the OS, heat, power, network, or YouTube may stop the stream.
