const express=require('express');
const multer=require('multer');
const fs=require('fs');
const path=require('path');
const {spawn}=require('child_process');
const app=express();
const ROOT=__dirname, VIDEO_DIR=path.join(ROOT,'videos'), SETTINGS_FILE=path.join(ROOT,'stream-settings.json');
const PORT=Number(process.env.PORT||3000);
app.use(express.json({limit:'1mb'}));
app.use(express.static(path.join(ROOT,'public')));
let keys={horizontal:'',vertical:''};
let children={horizontal:null,vertical:null};
let logs=[];
function log(s){const line=`${new Date().toLocaleTimeString()} ${s}`;logs.push(line);if(logs.length>250)logs=logs.slice(-250);console.log(line)}
function readSettings(){try{return JSON.parse(fs.readFileSync(SETTINGS_FILE,'utf8'))}catch{return {outputMode:'horizontal',resolution:'480p',fps:24,videoBitrate:2500,audioBitrate:96,sampleRate:44100,preset:'ultrafast'}}}
function writeSettings(s){const old=readSettings();const n={...old,...s};if(!['horizontal','vertical','both'].includes(n.outputMode))throw Error('Invalid orientation');if(!['480p','720p','1080p'].includes(n.resolution))throw Error('Invalid resolution');n.fps=[24,30,60].includes(Number(n.fps))?Number(n.fps):24;n.videoBitrate=Math.max(500,Math.min(8000,Number(n.videoBitrate)||2500));n.audioBitrate=Math.max(32,Math.min(192,Number(n.audioBitrate)||96));n.sampleRate=[44100,48000].includes(Number(n.sampleRate))?Number(n.sampleRate):44100;n.preset=['ultrafast','veryfast','faster','fast'].includes(n.preset)?n.preset:'ultrafast';fs.writeFileSync(SETTINGS_FILE,JSON.stringify(n,null,2));return n}
fs.mkdirSync(VIDEO_DIR,{recursive:true});if(!fs.existsSync(SETTINGS_FILE))writeSettings({});
const storage=multer.diskStorage({destination:(req,file,cb)=>cb(null,VIDEO_DIR),filename:(req,file,cb)=>{const ext=path.extname(file.originalname).toLowerCase();cb(null,Date.now()+'-'+Math.random().toString(36).slice(2,7)+ext)}});
const upload=multer({storage,limits:{fileSize:500*1024*1024},fileFilter:(req,file,cb)=>{if(!['.mp4','.mov','.mkv','.webm','.m4v'].includes(path.extname(file.originalname).toLowerCase()))return cb(new Error('Use MP4, MOV, MKV, WEBM, or M4V video files'));cb(null,true)}});
function videos(){return fs.readdirSync(VIDEO_DIR).filter(f=>/\.(mp4|mov|mkv|webm|m4v)$/i.test(f)).map(name=>({name,url:'/videos/'+encodeURIComponent(name)}))}
app.use('/videos',express.static(VIDEO_DIR));
app.get('/health',(req,res)=>res.json({ok:true}));
app.get('/api/videos',(req,res)=>res.json(videos()));
app.post('/api/upload',upload.single('video'),(req,res)=>{if(!req.file)return res.status(400).json({error:'Choose a video file'});res.json({message:'Upload complete',name:req.file.filename})});
app.get('/api/settings',(req,res)=>res.json(readSettings()));
app.post('/api/settings',(req,res)=>{try{if(Object.values(children).some(Boolean))return res.status(409).json({error:'Stop streaming before changing settings'});res.json(writeSettings(req.body||{}))}catch(e){res.status(400).json({error:e.message})}});
app.post('/api/stream-key',(req,res)=>{const key=String(req.body?.key||'').trim();if(!key)return res.status(400).json({error:'Enter a stream key'});const mode=readSettings().outputMode;if(mode==='both')return res.status(400).json({error:'For Both mode use /api/stream-keys with horizontal and vertical keys'});keys[mode]=key;res.json({message:`${mode} key stored in memory for this server session`})});
app.post('/api/stream-keys',(req,res)=>{const h=String(req.body?.horizontal||'').trim(),v=String(req.body?.vertical||'').trim();if(!h||!v)return res.status(400).json({error:'Both horizontal and vertical keys are required'});keys.horizontal=h;keys.vertical=v;res.json({message:'Both keys stored in memory for this session'})});
app.post('/api/stream-key/clear',(req,res)=>{keys={horizontal:'',vertical:''};res.json({message:'Stream keys cleared from memory'})});
function stopOne(mode){const p=children[mode];if(p){p.kill('SIGTERM');children[mode]=null;log(`${mode} stream stopped`);}}
function startOne(mode,key,s){return new Promise((resolve,reject)=>{if(!key)return reject(new Error(`Missing ${mode} stream key`));const env={...process.env,STREAM_KEY:key,OUTPUT_MODE:mode,RESOLUTION:s.resolution,FPS:String(s.fps),VIDEO_BITRATE:String(s.videoBitrate),AUDIO_BITRATE:String(s.audioBitrate),SAMPLE_RATE:String(s.sampleRate),PRESET:s.preset};const p=spawn('bash',[path.join(ROOT,'stream.sh')],{cwd:ROOT,env,stdio:['ignore','pipe','pipe']});children[mode]=p;let settled=false;const timer=setTimeout(()=>{if(!settled){settled=true;resolve()}},1200);const ondata=b=>{for(const line of b.toString().split(/\r?\n/).filter(Boolean))log(`[${mode}] ${line}`)};p.stdout.on('data',ondata);p.stderr.on('data',ondata);p.on('error',e=>{clearTimeout(timer);children[mode]=null;if(!settled){settled=true;reject(e)}});p.on('exit',(code,signal)=>{clearTimeout(timer);if(children[mode]===p)children[mode]=null;log(`${mode} FFmpeg exited (code=${code}, signal=${signal||'none'})`);if(!settled){settled=true;reject(new Error(`${mode} stream exited immediately; check logs and FFmpeg`))}});});}
app.get('/api/stream/status',(req,res)=>res.json({running:Object.values(children).some(Boolean),outputs:{horizontal:!!children.horizontal,vertical:!!children.vertical},logs:logs.slice(-80)}));
app.post('/api/stream/start',async(req,res)=>{if(Object.values(children).some(Boolean))return res.status(409).json({error:'A stream is already running. Stop it first.'});const files=videos();if(!files.length)return res.status(400).json({error:'Upload at least one video first'});const s=readSettings();const modes=s.outputMode==='both'?['horizontal','vertical']:[s.outputMode];for(const m of modes)if(!keys[m])return res.status(400).json({error:`Missing ${m} stream key. Save the key in the dashboard first.`});try{for(const m of modes)await startOne(m,keys[m],s);res.json({message:`Started ${modes.join(' + ')} stream output(s)`,outputs:modes})}catch(e){for(const m of modes)stopOne(m);res.status(500).json({error:e.message})}});
app.post('/api/stream/stop',(req,res)=>{stopOne('horizontal');stopOne('vertical');res.json({message:'Stop requested for all outputs'})});
app.use((err,req,res,next)=>res.status(400).json({error:err.message||'Request failed'}));
app.listen(PORT,'127.0.0.1',()=>console.log(`Website running at http://127.0.0.1:${PORT}`));
process.on('SIGINT',()=>{stopOne('horizontal');stopOne('vertical');process.exit(0)});
