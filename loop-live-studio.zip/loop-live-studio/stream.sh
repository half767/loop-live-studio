#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
: "${STREAM_KEY:?Missing STREAM_KEY}"
: "${OUTPUT_MODE:?Missing OUTPUT_MODE}"
command -v ffmpeg >/dev/null 2>&1 || { echo 'ERROR: FFmpeg not installed. Run: pkg install ffmpeg'; exit 1; }
shopt -s nullglob
files=("$PWD"/videos/*.mp4 "$PWD"/videos/*.MP4 "$PWD"/videos/*.mov "$PWD"/videos/*.MOV "$PWD"/videos/*.mkv "$PWD"/videos/*.MKV "$PWD"/videos/*.webm "$PWD"/videos/*.WEBM "$PWD"/videos/*.m4v "$PWD"/videos/*.M4V)
((${#files[@]})) || { echo 'ERROR: No supported videos in videos/'; exit 1; }
playlist="$PWD/.stream-playlist-${OUTPUT_MODE}.txt"
: > "$playlist"
for f in "${files[@]}"; do printf "file '%s'\n" "${f//\'/\'\\\'\'}" >> "$playlist"; done
case "${RESOLUTION:-480p}" in 720p) H=720; W=1280;; 1080p) H=1080; W=1920;; *) H=480; W=854;; esac
if [[ "$OUTPUT_MODE" == vertical ]]; then OUT_W=$H; OUT_H=$W; else OUT_W=$W; OUT_H=$H; fi
FPS=${FPS:-24}; VB=${VIDEO_BITRATE:-2500}; AB=${AUDIO_BITRATE:-96}; SR=${SAMPLE_RATE:-44100}; PRESET=${PRESET:-ultrafast}
echo "Starting $OUTPUT_MODE output at ${OUT_W}x${OUT_H}, ${FPS} fps"
# Scale and pad to exact aspect ratio, preserving the entire source frame.
exec ffmpeg -hide_banner -loglevel info -re -stream_loop -1 -f concat -safe 0 -i "$playlist" \
  -vf "scale=${OUT_W}:${OUT_H}:force_original_aspect_ratio=decrease,pad=${OUT_W}:${OUT_H}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=${FPS}" \
  -c:v libx264 -preset "$PRESET" -pix_fmt yuv420p -b:v "${VB}k" -maxrate "${VB}k" -bufsize "$((VB*2))k" \
  -c:a aac -b:a "${AB}k" -ar "$SR" -ac 2 -f flv "rtmps://a.rtmps.youtube.com:443/live2/${STREAM_KEY}"
